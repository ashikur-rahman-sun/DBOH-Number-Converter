package swing;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import javax.swing.JLabel;
import javax.swing.JTextField;

public final class FramDemo extends JFrame {
    private ImageIcon Icon;
    private Container c;
    JLabel decName;
    JLabel binName;
    JLabel octName;
    JLabel hexName;
    
    JTextField decTextField;
    JTextField binTextField;
    JTextField octTextField;
    JTextField hexTextField;
    
    FramDemo ()
               {
                  Components();
               }
               public void Components()
               {
                   c =this.getContentPane();
                   c.setBackground(Color.YELLOW);
                  Icon = new ImageIcon(getClass().getResource("Convert_Number.Convert_Numberreii.png"));
                  this.setIconImage(Icon.getImage());
                      setLayout(new FlowLayout(FlowLayout.RIGHT));
      
                      
                      
                      
        decName = new JLabel ("Decimal : ");
        binName = new JLabel ("Binary : ");
        octName = new JLabel ("Octal : ");
        hexName = new JLabel ("Hexadecimal : ");
        
        decTextField = new JTextField(15);
        binTextField = new JTextField(15);
        octTextField = new JTextField(15);
        hexTextField = new JTextField(15);
        
        add(decName);
        add(decTextField);
        add(binName);
        add(binTextField);
        add(octName);
        add(octTextField);
        add(hexName);
        add(hexTextField);
        
        
        
        ConvAction CONVERT = new ConvAction();
        decTextField.addActionListener(CONVERT);
        binTextField.addActionListener(CONVERT);
        octTextField.addActionListener(CONVERT);
        hexTextField.addActionListener(CONVERT);
        
               }
               
         private class ConvAction implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent enterUser)
        {
            String bin,oct,hex,userGiven;
            int dec;
            if(enterUser.getSource() == decTextField)
            {
                userGiven = decTextField.getText();
                dec = Integer.parseInt(userGiven);
                bin = Integer.toBinaryString(dec);
                oct = Integer.toOctalString(dec);
                hex =Integer.toHexString(dec).toUpperCase();
                
                decTextField.setText(userGiven);
                binTextField.setText(bin);
                octTextField.setText(oct);
                hexTextField.setText(hex);               
            }
            else if(enterUser.getSource() == binTextField)
            {
                userGiven = binTextField.getText();
               
                dec = Integer.parseInt(userGiven,2);
                oct = Integer.toOctalString(dec);
                hex = Integer.toHexString(dec).toUpperCase();
                
                
                decTextField.setText(String.valueOf(dec));
                binTextField.setText(userGiven);
                octTextField.setText(oct);
                hexTextField.setText(hex); 
            }
              else if(enterUser.getSource() == octTextField)
            {
                userGiven = octTextField.getText();
               
                dec = Integer.parseInt(userGiven,8);
                bin = Integer.toBinaryString(dec);
                hex = Integer.toHexString(dec).toUpperCase();
                
                
                decTextField.setText(String.valueOf(dec));
                binTextField.setText(bin);
                octTextField.setText(userGiven);
                hexTextField.setText(hex); 
            }
              else if(enterUser.getSource() == hexTextField)
            {
                userGiven = hexTextField.getText();
                dec = Integer.parseInt(userGiven,16);
                bin = Integer.toBinaryString(dec);
                oct = Integer.toOctalString(dec);

                decTextField.setText(String.valueOf(dec));
                binTextField.setText(bin);
                octTextField.setText(oct);
                hexTextField.setText(userGiven);
            }    

        }
    }  
         
    public static void main(String[] args) {
       FramDemo frame = new FramDemo();
       frame.setVisible(true);
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.setBounds(700,225,265,150);
       frame.setTitle("Number Converter System");
       frame.setResizable(false);
       
    }

}
